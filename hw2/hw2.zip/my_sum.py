def my_sum(*args: tuple[any]) -> float:
    return sum(args)
