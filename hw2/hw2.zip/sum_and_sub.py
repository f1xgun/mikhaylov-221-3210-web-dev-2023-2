def sum_and_sub(a: float, b: float) -> list[float]:
    return [a + b, a - b]
