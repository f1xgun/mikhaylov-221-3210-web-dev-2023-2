def show_employee(name: str, salary: int = 10000):
    return f"{name}: {salary} ₽"
